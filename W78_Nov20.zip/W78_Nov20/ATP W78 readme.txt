PEW RESEARCH CENTER
Wave 78 American Trends Panel 
Dates: Nov. 12 - Nov. 17, 2020
Mode: Web
Sample: Full panel
Language: English and Spanish
N=11,818

***************************************************************************************************************************
NOTES


The Wave 78 survey is Pew Research Center's first survey after the 2020 election. An extra raking parameter was added to the weighting to align the data with voter turnout. A final adjustment was applied to the trimmed weights to ensure that turnout and the popular vote margin exactly matched the weighting benchmark.

Source:
Cook Political Report as of 4:55 PM, November 17 + projections from Dave Wasserman; VAP and VEP from 2018 ACS 1 year estimates, based on noninstitutionalized adults 18+ in US

Targets:
Biden			0.315
Trump			0.287
Other			0.011
Did not vote		0.3071
Ineligible to vote	0.0802

For Wasserman projections, see https://twitter.com/Redistrict/status/1328719459641683976

For a small number of respondents with high risk of identification, certain values have been randomly swapped with those of lower risk cases with similar characteristics.

***************************************************************************************************************************
WEIGHTS 


WEIGHT_W78 is the weight for the sample. Data for all Pew Research Center reports are analyzed using this weight.


***************************************************************************************************************************
Releases from this survey:

November 20, 2020 "Sharp Divisions on Vote Counts, as Biden Gets High Marks for His Post-Election Conduct"
https://www.pewresearch.org/politics/2020/11/20/sharp-divisions-on-vote-counts-as-biden-gets-high-marks-for-his-post-election-conduct/

November 20, 2020 "Most voters are �fearful� and �angry� about the state of the U.S., but a majority now are �hopeful,� too"
https://www.pewresearch.org/fact-tank/2020/11/20/most-voters-are-fearful-and-angry-about-the-state-of-the-u-s--but-a-majority-now-are-hopeful-too/

December 17, 2020 "Voters Say Those on the Other Side 'Don't Get' Them. Here's What They Want Them To Know"
https://www.pewresearch.org/politics/2020/12/17/voters-say-those-on-the-other-side-dont-get-them-heres-what-they-want-them-to-know/

December 17, 2020 "What Biden and Trump supporters tell us in their own words about America's political divisions"
https://www.pewresearch.org/fact-tank/2020/12/17/what-biden-and-trump-supporters-tell-us-in-their-own-words-about-americas-political-divisions/




