PEW RESEARCH CENTER
Wave 75 American Trends Panel 
Dates: September 30 - October 5, 2020
Mode: Web 
Sample: Full panel
Language: English and Spanish
N=11,929

***************************************************************************************************************************
NOTES

For a small number of respondents with high risk of identification, certain values have been randomly swapped with those of lower risk cases with similar characteristics.


***************************************************************************************************************************
WEIGHTS 

The Wave 75 dataset contains two weights:

WEIGHT_W75 is the weight for the sample. Data for most Pew Research Center reports are analyzed using this weight.

WEIGHT_W39_W75 is a longitudinal weight for respondents to both Wave 39 and Wave 75.

***************************************************************************************************************************
Releases from this survey:

*All Pew Research Center research on coronavirus can be found at https://www.pewresearch.org/topics/coronavirus-disease-2019-covid-19/***


October 09, 2020 "Amid Campaign Turmoil, Biden Holds Wide Leads on Coronavirus, Unifying the Country"
https://www.pewresearch.org/politics/2020/10/09/amid-campaign-turmoil-biden-holds-wide-leads-on-coronavirus-unifying-the-country/

October 14, 2020 "Deep Divisions in Views of the Election Process - and Whether It Will Be Clear Who Won"
https://www.pewresearch.org/politics/2020/10/14/deep-divisions-in-views-of-the-election-process-and-whether-it-will-be-clear-who-won/

October 21, 2020 "Large Shares of Voters Plan To Vote a Straight Party Ticket for President, Senate and House"
https://www.pewresearch.org/politics/2020/10/21/large-shares-of-voters-plan-to-vote-a-straight-party-ticket-for-president-senate-and-house/



